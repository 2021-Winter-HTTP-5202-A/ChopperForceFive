<?php
    require_once '../Stylesheets/reports_page.css';

include 'header.php';
include 'nav.php';
include 'body_home.php';
include 'footer.php';
//Asia Levesque-->
?>
