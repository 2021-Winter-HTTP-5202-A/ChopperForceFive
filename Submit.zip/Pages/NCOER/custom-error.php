<?php

echo "<h2>NCOER DB ERR</h2>";
echo $msg;