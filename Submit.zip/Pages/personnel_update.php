<?php 
  include "header.php"; 
  include "nav.php"; 
?>
<link rel="stylesheet" href="../Stylesheets/reports_page.css">

<?php 
  require_once '../Models/DatabaseContext.php';
  require_once '../Models/User.php';
  require_once './personal_report/update.php';
  include "footer.php"; 
?>
