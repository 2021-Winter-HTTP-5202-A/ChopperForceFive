
<?php

require 'header.php';
require 'nav.php';


require_once '../Models/DatabaseContext.php';
require_once '../Models/User.php';
require_once './soldier_info/soldier_info_form.php';
require 'footer.php';
?>
<!-- User Upload Page(Documents, Awards, qualifications)(Journey Gault)
C.User can create new records
R.User can read previous records`
U.User can update records
D.Admin can delete records. -->
