<?php

echo "<h2>OER DB ERR</h2>";
echo $msg;