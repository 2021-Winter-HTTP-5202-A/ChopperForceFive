<?php
    require_once 'header.php';
?>
    <style>
        <?php
            require_once '../Stylesheets/reports_page.css';
        ?>
    </style>
<?php
    require_once '../Models/OER.php';
    require_once "../Models/DatabaseContext.php";
    require_once 'nav.php';
    require_once './OER/oer_report_list.php';
    require_once 'footer.php';
?>
<!--Asia Levesque-->