<div class="footer">
    <p>Copyright 2021 by Chopper Force Five. All Rights Reserved.</p>
</div>
</body>
<!--Asia Levesque-->