<?php 
    require_once 'header.php';
?>
<style>
<?php
    require_once '../Stylesheets/reports_page.css';
?>
</style>
<?php 
    require_once 'nav.php';
    require_once './body/weapons/wq_update.php';
    require_once 'footer.php'; 
?>