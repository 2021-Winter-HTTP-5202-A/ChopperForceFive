
<?php

require 'header.php';
require 'nav.php';
//require '../stylesheets/form.css';

require_once './duties_report/duties_report_list.php';

require 'footer.php';
?>
