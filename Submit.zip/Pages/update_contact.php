<?php 
    require_once 'header.php';
?>
<style>
<?php
    require_once '../Stylesheets/reports_page.css';
?>
</style>
<?php 
    require_once 'nav.php';
    require_once './body/emergency-contact/update_contact.php';
    require_once 'footer.php'; 
?>